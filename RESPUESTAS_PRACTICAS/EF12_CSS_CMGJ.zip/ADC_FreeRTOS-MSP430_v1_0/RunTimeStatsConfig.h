/*
 * RunTimeStatsConfig.h
 *
 *  Created on: 21/01/2015
 *      Author: jmcg
 */

#ifndef RUNTIMESTATSCONFIG_H_
#define RUNTIMESTATSCONFIG_H_


inline uint32_t GetOverflowCounts();
void vConfigureTimerForRunTimeStats( void );


#endif /* RUNTIMESTATSCONFIG_H_ */
